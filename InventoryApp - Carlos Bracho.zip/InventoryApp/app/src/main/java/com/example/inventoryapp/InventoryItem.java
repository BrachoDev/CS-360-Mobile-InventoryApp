package com.example.inventoryapp;

/**
 * InventoryItem Model Class
 * Represents a single inventory item with part number, name, location, and quantity
 * Follows Java Bean pattern with private fields and public getters/setters
 */
public class InventoryItem {

    // Private fields to encapsulate the data
    private String partNumber;  // Unique identifier for the item
    private String name;        // Descriptive name of the item
    private String bin;         // Physical storage location
    private int quantity;       // Current stock quantity
    private int id;             // database ID

    /**
     * Constructor - Creates a new InventoryItem with specified properties
     * @param partNumber The unique part number identifier
     * @param name The descriptive name of the item
     * @param bin The storage bin location
     * @param quantity The initial quantity in stock
     */
    public InventoryItem(String partNumber, String name, String bin, int quantity) {
        this.partNumber = partNumber;
        this.name = name;
        this.bin = bin;
        this.quantity = quantity;
    }

    // --- GETTER METHODS ---
    // Provide read access to private fields

    /**
     * @return The unique part number of this item
     */
    public String getPartNumber() {
        return partNumber;
    }

    /**
     * @return The descriptive name of this item
     */
    public String getName() {
        return name;
    }

    /**
     * @return The storage bin location of this item
     */
    public String getBin() {
        return bin;
    }

    /**
     * @return The current quantity of this item in stock
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * @return The id of this item in stock
     */
    public int getId() {return id;}

    // --- SETTER METHODS ---
    // Provide write access to private fields with validation

    /**
     * Updates the quantity of this item
     * @param quantity The new quantity (should be non-negative)
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public void setId(int id) {this.id = id;}
}

