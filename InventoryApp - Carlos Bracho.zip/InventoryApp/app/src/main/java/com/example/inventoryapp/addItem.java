package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * addItem Activity - Handles creation of new inventory items
 * Collects user input and returns data to the calling activity
 */
public class addItem extends AppCompatActivity {

    // UI component references
    private EditText itemNumberInput, itemNameInput, itemQuantityInput, binLocationInput;
    private Button saveItemButton;

    // Constants for validation
    private static final int MIN_QUANTITY = 0;
    private static final int MAX_QUANTITY = 1000; // Reasonable upper limit

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inflate the add item layout
        setContentView(R.layout.activity_add_item);

        // Initialize all UI components
        initializeViews();

        // Set up button click listener
        setupSaveButton();
    }

    /**
     * Finds and stores references to all UI components
     */
    private void initializeViews() {
        itemNumberInput = findViewById(R.id.itemNumberInput);
        itemNameInput = findViewById(R.id.itemNameInput);
        itemQuantityInput = findViewById(R.id.itemQuantityInput);
        binLocationInput = findViewById(R.id.binLocationInput);
        saveItemButton = findViewById(R.id.saveItemButton);
    }

    /**
     * Sets up the save button with validation and data processing
     */
    private void setupSaveButton() {
        saveItemButton.setOnClickListener(v -> {
            // Validate input before proceeding
            if (validateInput()) {
                processAndReturnData();
            }
        });
    }

    /**
     * Validates all input fields
     * @return true if all input is valid, false otherwise
     */
    private boolean validateInput() {
        String partNumber = itemNumberInput.getText().toString().trim();
        String name = itemNameInput.getText().toString().trim();
        String bin = binLocationInput.getText().toString().trim();
        String quantityText = itemQuantityInput.getText().toString().trim();

        // Check for empty required fields
        if (partNumber.isEmpty()) {
            showError("Item Number cannot be empty");
            itemNumberInput.requestFocus();
            return false;
        }

        if (name.isEmpty()) {
            showError("Item Name cannot be empty");
            itemNameInput.requestFocus();
            return false;
        }

        if (quantityText.isEmpty()) {
            showError("Quantity cannot be empty");
            itemQuantityInput.requestFocus();
            return false;
        }

        if (bin.isEmpty()) {
            showError("Bin cannot be empty");
            binLocationInput.requestFocus();
            return false;
        }

        // Validate quantity is a positive number
        try {
            int quantity = Integer.parseInt(quantityText);
            if (quantity < MIN_QUANTITY) {
                showError("Quantity cannot be negative");
                itemQuantityInput.requestFocus();
                return false;
            }
            if (quantity > MAX_QUANTITY) {
                showError("Quantity cannot exceed " + MAX_QUANTITY);
                itemQuantityInput.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            showError("Please enter a valid number for quantity");
            itemQuantityInput.requestFocus();
            return false;
        }

        return true;
    }

    /**
     * Processes validated input and returns data to calling activity
     */
    private void processAndReturnData() {
        // Extract and trim input values
        String partNumber = itemNumberInput.getText().toString().trim();
        String name = itemNameInput.getText().toString().trim();
        String bin = binLocationInput.getText().toString().trim();
        int quantity = Integer.parseInt(itemQuantityInput.getText().toString().trim());

        // Create result intent with extracted data
        Intent resultIntent = new Intent();
        resultIntent.putExtra("partNumber", partNumber);
        resultIntent.putExtra("name", name);
        resultIntent.putExtra("bin", bin);
        resultIntent.putExtra("quantity", quantity);

        // Set result and finish activity
        setResult(RESULT_OK, resultIntent);

        // Show confirmation message
        Toast.makeText(this, "Item '" + name + "' added successfully!", Toast.LENGTH_SHORT).show();

        finish(); // Close activity and return to inventory screen
    }

    /**
     * Shows error message to user
     * @param message The error message to display
     */
    private void showError(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }
}

