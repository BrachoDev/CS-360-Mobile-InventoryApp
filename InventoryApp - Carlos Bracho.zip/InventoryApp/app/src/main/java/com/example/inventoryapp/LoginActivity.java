package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

/**
 * LoginActivity - Handles user authentication and account creation
 */
public class LoginActivity extends AppCompatActivity {

    // UI components
    private EditText usernameField, passwordField, confirmPasswordField;
    private Button createAccountButton, loginButton;

    // Database helper instance
    private DatabaseHelper dbHelper;


    // Tracks if user is creating an account
    private boolean isCreatingAccount = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DatabaseHelper(this);
        initializeViews();
        setupButtonListeners();
    }

    /** Initializes UI components */
    private void initializeViews() {
        usernameField = findViewById(R.id.usernameField);
        passwordField = findViewById(R.id.passwordField);
        confirmPasswordField = findViewById(R.id.confirmPasswordField);
        createAccountButton = findViewById(R.id.createAccountButton);
        loginButton = findViewById(R.id.loginButton);
    }

    /** Sets up click listeners for buttons */
    private void setupButtonListeners() {
        loginButton.setOnClickListener(v -> handleLogin());
        createAccountButton.setOnClickListener(v -> {
            if (!isCreatingAccount) switchToAccountCreationMode();
            else attemptAccountCreation();
        });
    }

    /** Handles user login */
    private void handleLogin() {
        if (!validateLoginInput()) return;

        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString();

        if (dbHelper.checkUserCredentials(username, password)) {
            Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
            openInventoryActivity();
        } else {
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    /** Validates login fields */
    private boolean validateLoginInput() {
        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString();

        if (username.isEmpty()) {
            usernameField.setError("Username required");
            return false;
        }
        if (password.isEmpty()) {
            passwordField.setError("Password required");
            return false;
        }
        return true;
    }

    /* Switches UI to account creation mode */
    private void switchToAccountCreationMode() {
        confirmPasswordField.setVisibility(View.VISIBLE);
        createAccountButton.setText("Submit New Account");
        isCreatingAccount = true;
        clearAllErrors();
    }

    /* Handles account creation logic */
    private void attemptAccountCreation() {
        if (!validateAccountCreationInput()) {
            Toast.makeText(this, "Please fix the errors above", Toast.LENGTH_SHORT).show();
            return;
        }

        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString();

        if (dbHelper.doesUserExist(username)) {
            usernameField.setError("Username already taken");
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            return;
        }

        if (dbHelper.registerUser(username, password)) {
            Toast.makeText(this, "Account created successfully! Please log in.", Toast.LENGTH_SHORT).show();
            resetToLoginMode();
        } else {
            Toast.makeText(this, "Error creating account", Toast.LENGTH_SHORT).show();
        }
    }

    /** Validates fields for account creation */
    private boolean validateAccountCreationInput() {
        String username = usernameField.getText().toString().trim();
        String password = passwordField.getText().toString();
        String confirm = confirmPasswordField.getText().toString();

        if (username.length() < 6) {
            usernameField.setError("At least 6 characters");
            return false;
        }
        if (password.length() < 4) {
            passwordField.setError("At least 4 characters");
            return false;
        }
        if (!password.equals(confirm)) {
            confirmPasswordField.setError("Passwords must match");
            return false;
        }
        return true;
    }

    /** Resets UI back to login mode after account creation */
    private void resetToLoginMode() {
        confirmPasswordField.setVisibility(View.GONE);
        createAccountButton.setText("Create Account");
        isCreatingAccount = false;
        clearAllErrors();
    }

    /** Clears input field errors */
    private void clearAllErrors() {
        usernameField.setError(null);
        passwordField.setError(null);
        confirmPasswordField.setError(null);
    }

    /** Opens the inventory activity */
    private void openInventoryActivity() {
        Intent intent = new Intent(this, inventoryActivity.class);
        startActivity(intent);
    }



}




