package com.example.inventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

/**
 * InventoryAdapter - RecyclerView adapter for displaying inventory items.
 *
 *   - Create item views (ViewHolder pattern)
 *   - Bind inventory data to each row
 *   - Handle user interactions (delete, increase/decrease quantity)
 */
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {

    // Data source
    private List<InventoryItem> itemList; // List of inventory items to display
    private OnItemDeleteListener deleteListener; // Listener for delete actions
    private OnQuantityChangeListener quantityChangeListener; // Listener for quantity changes

    /**
     * Interface for notifying the activity when an item is deleted
     */
    public interface OnItemDeleteListener {
        void onItemDelete(int position); // Position in the list of the deleted item
    }

    /**
     * Interface for notifying the activity when item quantity changes
     */
    public interface OnQuantityChangeListener {
        void onQuantityIncrease(int position); // Called when user increases quantity
        void onQuantityDecrease(int position); // Called when user decreases quantity
    }

    /**
     * Constructor - Initializes adapter with data and listeners
     *
     * @param itemList List of inventory items
     * @param deleteListener Listener for delete actions
     * @param quantityChangeListener Listener for quantity changes
     */
    public InventoryAdapter(List<InventoryItem> itemList,
                            OnItemDeleteListener deleteListener,
                            OnQuantityChangeListener quantityChangeListener) {
        this.itemList = itemList;
        this.deleteListener = deleteListener;
        this.quantityChangeListener = quantityChangeListener;
    }

    /**
     * Called when RecyclerView needs a new ViewHolder (row) to display
     */
    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate row layout
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_inventory_row, parent, false);
        return new InventoryViewHolder(view);
    }

    /**
     * Called to bind data to an existing ViewHolder
     * @param holder The ViewHolder to bind data to
     * @param position Position of the item in the list
     */
    @Override
    public void onBindViewHolder(@NonNull InventoryViewHolder holder, int position) {
        InventoryItem item = itemList.get(position);

        // Bind inventory data to UI components
        holder.partNumber.setText("Part#: " + item.getPartNumber());
        holder.itemName.setText("Name: " + item.getName());
        holder.binLocation.setText("Bin: " + item.getBin());
        holder.itemQuantity.setText("Quantity: " + item.getQuantity());

        // Handle button clicks

        // Delete button: notify activity to remove this item
        holder.deleteButton.setOnClickListener(v -> {
            if (deleteListener != null) deleteListener.onItemDelete(position);
        });

        // Increase quantity button: notify activity to increase quantity
        holder.increaseButton.setOnClickListener(v -> {
            if (quantityChangeListener != null) quantityChangeListener.onQuantityIncrease(position);
        });

        // Decrease quantity button: notify activity to decrease quantity
        holder.decreaseButton.setOnClickListener(v -> {
            if (quantityChangeListener != null) quantityChangeListener.onQuantityDecrease(position);
        });
    }

    /**
     * Returns total number of items in the list
     */
    @Override
    public int getItemCount() {
        return itemList.size();
    }

    /**
     * ViewHolder class - Holds references to the views for each row.
     * This avoids repeatedly calling findViewById, improving performance.
     */
    public static class InventoryViewHolder extends RecyclerView.ViewHolder {
        TextView partNumber, itemName, binLocation, itemQuantity; // Display inventory info
        Button deleteButton, increaseButton, decreaseButton; // Action buttons

        public InventoryViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initialize UI components from layout
            partNumber = itemView.findViewById(R.id.partNumber);
            itemName = itemView.findViewById(R.id.itemName);
            binLocation = itemView.findViewById(R.id.binLocation);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            increaseButton = itemView.findViewById(R.id.increaseButton);
            decreaseButton = itemView.findViewById(R.id.decreaseButton);
        }
    }
}


