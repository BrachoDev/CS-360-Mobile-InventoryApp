package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * DatabaseHelper - Handles creation, upgrade, and access to the SQLite database
 *
 *   - Define the database schema (users and inventory tables)
 *   - Provide CRUD operations for users and inventory items
 *   - Handle database version upgrades
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database configuration
    private static final String DATABASE_NAME = "inventory_app.db"; // Database file name
    private static final int DATABASE_VERSION = 2; // Increment when schema changes

    // User table constants
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Inventory table constants
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COLUMN_ITEM_ID = "item_id";
    private static final String COLUMN_PART_NUMBER = "partNumber";
    private static final String COLUMN_NAME = "name";
    private static final String COLUMN_BIN = "bin";
    private static final String COLUMN_QUANTITY = "quantity";

    /**
     * Constructor - initializes the database helper
     * @param context The activity context
     */
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Called once when the database is first created.
     * This method creates the tables for users and inventory.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL statement to create users table
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USERNAME + " TEXT UNIQUE, "
                + COLUMN_PASSWORD + " TEXT)";
        db.execSQL(CREATE_USERS_TABLE);

        // SQL statement to create inventory table
        String CREATE_INVENTORY_TABLE = "CREATE TABLE " + TABLE_INVENTORY + " ("
                + COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_PART_NUMBER + " TEXT, "
                + COLUMN_NAME + " TEXT, "
                + COLUMN_BIN + " TEXT, "
                + COLUMN_QUANTITY + " INTEGER)";
        db.execSQL(CREATE_INVENTORY_TABLE);
    }

    /**
     * Called when the database version is increased.
     * Drops old tables and recreates them to match the new schema.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop existing tables
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);

        // Recreate tables
        onCreate(db);
    }

    // User-related operations

    /**
     * Registers a new user in the database.
     * @param username User's chosen username (must be unique)
     * @param password User's password
     * @return true if the user was successfully added
     */
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values); // insert returns -1 if failed
        db.close();
        return result != -1;
    }

    /**
     * Checks if a user already exists in the database.
     * @param username The username to check
     * @return true if the user exists
     */
    public boolean doesUserExist(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COLUMN_ID},
                COLUMN_USERNAME + "=?",
                new String[]{username},
                null, null, null
        );
        boolean exists = cursor.moveToFirst(); // true if a row exists
        cursor.close();
        db.close();
        return exists;
    }

    /**
     * Checks if a username/password combination is valid.
     * @param username The username
     * @param password The password
     * @return true if credentials match a user in the database
     */
    public boolean checkUserCredentials(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_USERS,
                new String[]{COLUMN_ID},
                COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null
        );
        boolean valid = cursor.moveToFirst();
        cursor.close();
        db.close();
        return valid;
    }

    /**
     * Deletes all users from the database.
     * Useful for testing or resetting the database.
     */
    public void deleteAllUsers() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_USERS, null, null);
        db.close();
    }

    // Inventory-related operations

    /**
     * Adds a new inventory item to the database.
     * @param item The InventoryItem object to add
     * @return true if insertion was successful
     */
    public boolean addInventoryItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PART_NUMBER, item.getPartNumber());
        values.put(COLUMN_NAME, item.getName());
        values.put(COLUMN_BIN, item.getBin());
        values.put(COLUMN_QUANTITY, item.getQuantity());
        long result = db.insert(TABLE_INVENTORY, null, values);
        db.close();
        return result != -1;
    }

    /**
     * Retrieves all inventory items from the database.
     * @return ArrayList of InventoryItem objects
     */
    public ArrayList<InventoryItem> getAllInventoryItems() {
        ArrayList<InventoryItem> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_INVENTORY, null, null, null, null, null, null);

        if (cursor.moveToFirst()) {
            do {
                // Extract data for each inventory item
                String part = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PART_NUMBER));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME));
                String bin = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_BIN));
                int quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_QUANTITY));

                list.add(new InventoryItem(part, name, bin, quantity));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

    /**
     * Updates the quantity of an inventory item.
     * @param partNumber The part number of the item to update
     * @param newQuantity The new quantity value
     * @return true if update succeeded
     */
    public boolean updateInventoryQuantity(String partNumber, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_QUANTITY, newQuantity);

        // Update row where part number matches
        int rows = db.update(TABLE_INVENTORY, values, COLUMN_PART_NUMBER + "=?",
                new String[]{partNumber});
        db.close();
        return rows > 0;
    }

    /**
     * Deletes an inventory item by its part number.
     * @param partNumber The part number to delete
     * @return true if deletion succeeded
     */
    public boolean deleteInventoryItem(String partNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_INVENTORY, COLUMN_PART_NUMBER + "=?",
                new String[]{partNumber});
        db.close();
        return rows > 0;
    }
}
